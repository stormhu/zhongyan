<?php
namespace app\controller;
use think\Controller;

class Common extends Controller{
	// 1.登录状态检测

}