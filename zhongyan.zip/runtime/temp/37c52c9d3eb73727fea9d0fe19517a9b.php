<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:63:"E:\xampp\htdocs\company\zhongyan\public/../app/tpl/tuoguan.html";i:1492843436;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	
	<script type="text/javascript" src="__STATIC__/index/js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="__STATIC__/index/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="__STATIC__/index/js/myjs.js"></script>

	<link rel="stylesheet" type="text/css" href="__STATIC__/index/css/animate.min.css">
	<link rel="stylesheet" href="__STATIC__/index/css/bootstrap.min.css">
	<link rel="stylesheet" href="__STATIC__/index/css/style.css">
	
	<meta name="keywords" content="电商运营托管,电商课程培训,网站优化推广">
	<meta name="description" content="山东众焱信息咨询有限公司专注于德州网站制作，德州百度优化，德州阿里巴巴，德州网站优化，德州祥云平台等业务，最专业的设计团队最完善的网络售后服务，为您企业打造最赚钱的网络营销方案！">
	<title>网店托管 - 山东众焱信息咨询有限公司</title>
</head>
<body style="overflow-x:hidden;">
<!-- header区 -->
<?php include APP_PATH."tpl/header.html" ?>

<!-- <div class="container-fluid" style="background:url(__STATIC__/index/image/bg1.jpg) no-repeat top center; height:200px;">
	
</div> -->
<div class="jumbotron" style="background:url(__STATIC__/index/image/bg5.jpg) no-repeat bottom center; height:220px;">
	<div class="container">
		<h1 class="animated fadeInLeft" style="color:#fff">网店托管<br><small style="color:#fff;">让您在互联网上的业绩倍增!!</small></h1>
	</div>
</div>
<div class="container" style="min-height:300px;">
	<div class="row">
		<div class="col-md-12 box1" style="min-height:500px;">
			<h1 class="text-center">您是否已经焦头烂额？</h1>
			<img class="center-block hidden" src="__STATIC__/index/image/tuoguan/bg1.png">
		</div>
		<div class="col-md-12 box2" style="margin-bottom:30px; ">
			<h1 class="text-center " style="">以上问题，由我们帮您解决！</h1>
			<h5 class="text-center">多年金牌淘拍档，专业的技术及优先级的官方数据，以双赢为基本目标为每一位客户提供专业代运营服务！</h5>
		</div>
		<div class="col-md-12">
			<div class="center-block" style="width:250px; height:100px;">
				<a href="" class="center-block" style="display:block; text-decoration:none; width:200px; height:50px; text-align:center; background:url(__STATIC__/index/image/btn/200x50xb1.png);"><h4 style="color:#c30; line-height:45px;">立即解决</h4></a>
			</div>
		</div>
	</div>
</div>
<div class="container-fluid" style="min-height:168px; background:url(__STATIC__/index/image/tuoguan/p1.png);">
	<div class="container">
		<h1 style="color:#fff;">我们的托管，能给您带来真实的效益！！</h1>
		<h3 style="color:#fff;">从装修到运营，一站式解决方案</h3>
	</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-4" style="margin:30px 0px;min-height:300px;">
			<div class="center-block" style="width:250px;">
				<img class="center-block" src="__STATIC__/index/image/tuoguan/i1.png">
				<h3 class="text-center">沟通客户</h3>
				<p class="text-center">认真与客户沟通，充分了解客户需求，为客户提供高效解决方案</p>
				<a href="" class="center-block" style="display:block; text-decoration:none; width:200px; height:50px; text-align:center; background:url(__STATIC__/index/image/btn/200x50xb1.png);"><h4 style="color:#c30; line-height:45px;">马上咨询</h4></a>
			</div>
			
		</div>
		<div class="col-md-4" style="margin:30px 0px;min-height:300px;">
			<div class="center-block" style="width:250px;">
				<img class="center-block" src="__STATIC__/index/image/tuoguan/i2.png">
				<h3 class="text-center">素材整理</h3>
				<p class="text-center">仔细收集客户产品素材，为后期设计做好充足准备</p>
				<a href="" class="center-block" style="display:block; text-decoration:none; width:200px; height:50px; text-align:center; background:url(__STATIC__/index/image/btn/200x50xb1.png);"><h4 style="color:#c30; line-height:45px;">马上咨询</h4></a>
			</div>
		</div>
		<div class="col-md-4" style="margin:30px 0px;min-height:300px;">
			<div class="center-block" style="width:250px;">
				<img class="center-block" src="__STATIC__/index/image/tuoguan/i3.png">
				<h3 class="text-center">版面设计</h3>
				<p class="text-center">整体网店店面设计，千挑万选，为您提供合适的风格</p>
				<a href="" class="center-block" style="display:block; text-decoration:none; width:200px; height:50px; text-align:center; background:url(__STATIC__/index/image/btn/200x50xb1.png);"><h4 style="color:#c30; line-height:45px;">马上咨询</h4></a>
			</div>
		</div>
		<div class="col-md-6" style="margin:30px 0px;min-height:300px;">
			<div class="center-block" style="width:250px;">
				<img class="center-block" src="__STATIC__/index/image/tuoguan/i4.png">
				<h3 class="text-center">装修实施</h3>
				<p class="text-center">客户满意，着手装修美化，带给您具有视觉冲击的装修设计效果</p>
				<a href="" class="center-block" style="display:block; text-decoration:none; width:200px; height:50px; text-align:center; background:url(__STATIC__/index/image/btn/200x50xb1.png);"><h4 style="color:#c30; line-height:45px;">马上咨询</h4></a>
			</div>
		</div>
		<div class="col-md-6" style="margin:30px 0px;min-height:300px;">
			<div class="center-block" style="width:250px;">
				<img class="center-block" src="__STATIC__/index/image/tuoguan/i5.png">
				<h3 class="text-center">信息优化</h3>
				<p class="text-center">帮您维护打理您的网店，带给您更多的曝光量、询盘和成交量！为您带来真实的利益</p>
				<a href="" class="center-block" style="display:block; text-decoration:none; width:200px; height:50px; text-align:center; background:url(__STATIC__/index/image/btn/200x50xb1.png);"><h4 style="color:#c30; line-height:45px;">马上咨询</h4></a>
			</div>
		</div>
	</div>
</div>

<!-- footer -->
<?php include APP_PATH."tpl/footer.html"; ?>

</body>
<script type="text/javascript">
	$(document).ready(function(){
		$("#nav li").children(".n3").css("color","#c30");
	});
	var $win = $(window);
	var temp = 200;
	var box1OffsetTop = $(".box1").offset().top;
	var box1OffsetHeight = $("box1").outerHeight();
	var winHeight = $win.height();
	$win.scroll(function(){
		var winScrollTop = $win.scrollTop();
		// box1
		if(!(winScrollTop > box1OffsetTop+box1OffsetHeight) && !(winScrollTop-temp<box1OffsetTop-winHeight) && !($(".box1").hasClass("done"))){
			console.log("box1出现");
			$(".box1").children("img").removeClass("hidden");
			$(".box1").children("h3").removeClass("hidden");
			$(".box1").children("img").addClass("animated fadeInLeft done");
			$(".box1").children("h3").addClass("animated fadeInLeft done");
		}
		
	});
</script>

</html>



