<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:33:"../template/default/jianzhan.html";i:1492674402;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	
	<script type="text/javascript" src="/template/default/js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="/template/default/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/template/default/js/myjs.js"></script>

	<link rel="stylesheet" type="text/css" href="/template/default/css/animate.min.css">
	<link rel="stylesheet" href="/template/default/css/bootstrap.min.css">
	<link rel="stylesheet" href="/template/default/css/style.css">

	<title>网站建设-</title>
</head>
<body style="overflow-x:hidden;">
<!-- header区 -->
<?php include "../template/default/header.html" ?>

<!-- <div class="container-fluid" style="background:url(/template/default/image/bg1.jpg) no-repeat top center; height:200px;">
	
</div> -->
<div class="jumbotron" style="background:url(/template/default/image/bg6.jpg) no-repeat bottom center; height:220px;">
	<div class="container">
		<h1 style="color:#fff">网站建好了，却没营销效果？！</h1>
		<h2 style="color:#fff">建站、推广、都交给我们吧！</h2>
	</div>
</div>
<div class="container" style="min-height:300px;">
	<div class="row">
		<div class="col-md-5" style="min-height:400px;">
			<img style="max-width:100%;" src="/template/default/image/jianzhan/i1.png">
		</div>
		<div class="col-md-6">
			<h1 style="margin-top:100px;">如何打造一个网络赚钱机器？</h1>
			<h4>第一点：锁定搜索引擎</h4>
			<h4>第一点：帮助你找到您的目标客户一对一的策划让你的网站拥有高询盘率、高转化率，获得更多的订单</h4>
		</div>
		<div class="col-md-12">
			<!-- <h1 class="text-center">众焱制作的营销型网站</h1><h2 class="text-center">具备以下两大能力</h2> -->
			<img style="max-width:100%;" class="center-block" src="/template/default/image/jianzhan/i3.png">
		</div>
		<div class="col-md-12" style="padding:50px 0px; box-shadow:0px 0px 15px #aaa; margin-top:40px;">
			<div class="col-md-4">
				<img style="max-width:100%;" src="/template/default/image/jianzhan/i2.png" onmouseover="$(this).addClass('animated pulse')" onmouseout="$(this).removeClass('animated pulse')">
			</div>
			<div class="col-md-6">
				<h2 style="margin-top:50px;">让网站上线后推广更省钱</h2>
				<h4>为您的企业提炼精准关键词，并配合营销型网站的七大优化结构布局到网站，更容易让搜索引擎把您的网站排名到首页，继而获得更多流量</h4>
			</div>
		</div>
			
		<div class="col-md-12" style="padding:50px 0px; box-shadow:0px 0px 15px #aaa; margin-top:40px;">
			<div class="col-md-4 pull-right">
				<img style="max-width:100%;" src="/template/default/image/jianzhan/i4.png" onmouseover="$(this).addClass('animated pulse')" onmouseout="$(this).removeClass('animated pulse')">
			</div>
			<div class="col-md-6 pull-right">
				<h2 style="margin-top:50px;">让您的网络营销更赚钱</h2>
				<h4>同样的流量更多的询盘，为您赢得更多生意机会！根据您的产品和客户群，精心策划网页布局和能与4A公司作品相媲美的广告文案，让您的网站在同行网站中脱颖而出，获得目标客户的询盘和订单</h4>
			</div>
		</div>

		<div class="col-md-12" style="margin-top:50px;">
			<div class="col-md-3">
				
			</div>
		</div>

		<div class="col-md-12" >
			<h1 class="text-center" style="line-height:100px;">建站步骤:</h1>
			<div class="col-md-3" style="border-right:5px dotted #ccc;"><img style="max-width:100%;" src="/template/default/image/jianzhan/a1.png" onmouseover="$(this).addClass('animated bounce')" onmouseout="$(this).removeClass('animated bounce')"></div>
			<div class="col-md-3" style="border-right:5px dotted #ccc;"><img style="max-width:100%;" src="/template/default/image/jianzhan/a2.png" onmouseover="$(this).addClass('animated bounce')" onmouseout="$(this).removeClass('animated bounce')"></div>
			<div class="col-md-3" style="border-right:5px dotted #ccc;"><img style="max-width:100%;" src="/template/default/image/jianzhan/a3.png" onmouseover="$(this).addClass('animated bounce')" onmouseout="$(this).removeClass('animated bounce')"></div>
			<div class="col-md-3"><img style="max-width:100%;" src="/template/default/image/jianzhan/a4.png" onmouseover="$(this).addClass('animated bounce')" onmouseout="$(this).removeClass('animated bounce')"></div>
			<div class="col-md-12"><a href="#"><img class="center-block" src="/template/default/image/jianzhan/a5.png" onmouseover="$(this).addClass('animated pulse')" onmouseout="$(this).removeClass('animated pulse')"></a></div>
		</div>
		
	</div>
</div>

<!-- footer -->
<?php include "../template/default/footer.html"; ?>

</body>
<script type="text/javascript">
	$(document).ready(function(){
		$("#nav li").children(".n4").css("color","#c30");
	});
</script>

</html>



