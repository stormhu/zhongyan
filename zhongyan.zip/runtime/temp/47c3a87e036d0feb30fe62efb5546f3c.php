<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:29:"../template/default/anli.html";i:1492677376;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	
	<script type="text/javascript" src="/template/default/js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="/template/default/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/template/default/js/myjs.js"></script>

	<link rel="stylesheet" type="text/css" href="/template/default/css/animate.min.css">
	<link rel="stylesheet" href="/template/default/css/bootstrap.min.css">
	<link rel="stylesheet" href="/template/default/css/style.css">

	<title>电商培训-</title>
</head>
<body style="overflow-x:hidden;">
<!-- header区 -->
<?php include "../template/default/header.html" ?>

<!-- <div class="container-fluid" style="background:url(/template/default/image/bg1.jpg) no-repeat top center; height:200px;">
	
</div> -->
<!-- <div class="jumbotron" style="background:url(/template/default/image/bg6.jpg) no-repeat top center; min-height:220px;">
	<div class="container">
		<h1 class="animated fadeInLeft" style="color:#fff">众焱电商6年来专注于网络营销系统落地</h1>
		<h3 class="animated fadeInLeft" style="color:#fff;"><span style="display:inline-block; width:20px; height:20px; border-radius:20px; background:#fff; margin-right:20px;"></span>授课企业超过1.5万家</h3>
		<h3 class="animated fadeInLeft" style="color:#fff;"><span style="display:inline-block; width:20px; height:20px; border-radius:20px; background:#fff; margin-right:20px;"></span>服务过的细分市场超过800个</h3>
	</div>
</div> -->
<div class="jumbotron" style="background:url(/template/default/image/anli/p1.png) no-repeat top center; min-height:168px;">
	<div class="container">
		<h1 class="text-center" style="color:#fff;">建站案例展示</h1>
	</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-4">
			<div class="thumbnail">
				<img src="/template/default/image/anli/j1.jpg">
				<div class="caption">
					<h3>金利来</h3>
					<h4>公司名称：德州金利来机械设备有限公司</h4>
					<a class="btn btn-default" href="">查看详情</a>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="thumbnail">
				<img src="/template/default/image/anli/j3.jpg">
				<div class="caption">
					<h3>建筑装饰</h3>
					<h4>公司名称：昆山建筑装饰工程有限公司</h4>
					<a class="btn btn-default" href="">查看详情</a>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="thumbnail">
				<img src="/template/default/image/anli/j2.jpg">
				<div class="caption">
					<h3>美京电器</h3>
					<h4>公司名称：上海美京电器有限公司</h4>
					<a class="btn btn-default" href="">查看详情</a>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="thumbnail">
				<img src="/template/default/image/anli/j4.jpg">
				<div class="caption">
					<h3>海鸥起重</h3>
					<h4>公司名称：常熟海鸥起重机械有限公司</h4>
					<a class="btn btn-default" href="">查看详情</a>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="thumbnail">
				<img src="/template/default/image/anli/j5.jpg">
				<div class="caption">
					<h3>海特尔</h3>
					<h4>公司名称：江苏海特尔机械有限公司</h4>
					<a class="btn btn-default" href="">查看详情</a>
				</div>
			</div>
		</div>
		
		
	</div>
</div>

<div class="jumbotron" style="background:url(/template/default/image/anli/p1.png) no-repeat top center; min-height:168px;">
	<div class="container">
		<h1 class="text-center" style="color:#fff;">阿里托管展示</h1>
	</div>
</div>

<div class="container">
	<div class="row">
		<div class="col-md-4">
			<div class="thumbnail">
				<img src="/template/default/image/anli/a1.jpg">
				<div class="caption">
					<h3>中牧孵化</h3>
					<h4>公司全称：德州市德城区中牧孵化设备厂</h4>
					<a class="btn btn-default" href="">查看详情</a>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="thumbnail">
				<img src="/template/default/image/anli/a2.jpg">
				<div class="caption">
					<h3>华翔新材料</h3>
					<h4>公司全称：德州华翔新材料科技有限公司</h4>
					<a class="btn btn-default" href="">查看详情</a>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="thumbnail">
				<img src="/template/default/image/anli/a3.jpg">
				<div class="caption">
					<h3>宇涵中央空调</h3>
					<h4>公司全称：德州宇涵中央空调有限公司</h4>
					<a class="btn btn-default" href="">查看详情</a>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="thumbnail">
				<img src="/template/default/image/anli/a4.jpg">
				<div class="caption">
					<h3>旭隆机械</h3>
					<h4>公司全称：德州市旭隆机械制造有限公司</h4>
					<a class="btn btn-default" href="">查看详情</a>
				</div>
			</div>
		</div>
	</div>
</div>


<!-- footer -->
<?php include "../template/default/footer.html"; ?>

</body>
<script type="text/javascript">
	$(document).ready(function(){
		$("#nav li").children(".n5").css("color","#c30");
	});
</script>
</html>



